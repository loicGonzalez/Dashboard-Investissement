"""Connecteurs externes (Powens, etc.)."""
